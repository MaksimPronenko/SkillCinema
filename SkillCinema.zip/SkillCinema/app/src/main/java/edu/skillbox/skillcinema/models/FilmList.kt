package edu.skillbox.skillcinema.models

class FilmList(
    val total: Int,
    val items: List<FilmPremiere>
)