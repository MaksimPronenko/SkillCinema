package edu.skillbox.skillcinema.models

data class ActorsAndStaff(
    val actorsList: List<StaffTable>,
    val staffList: List<StaffTable>
)