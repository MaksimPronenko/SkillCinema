package edu.skillbox.skillcinema.models

data class Image(
    val imageUrl: String,
    val previewUrl: String
)