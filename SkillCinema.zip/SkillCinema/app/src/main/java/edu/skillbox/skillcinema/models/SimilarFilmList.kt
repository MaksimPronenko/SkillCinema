package edu.skillbox.skillcinema.models

data class SimilarFilmList(
    val total: Int,
    val items: List<SimilarFilm>
)
