package edu.skillbox.skillcinema.models

data class Genre(
    val genre: String
)
