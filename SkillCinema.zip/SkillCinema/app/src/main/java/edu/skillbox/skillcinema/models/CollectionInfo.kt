package edu.skillbox.skillcinema.models

data class CollectionInfo(
    val collectionName: String,
    val filmsQuantity: Int
)