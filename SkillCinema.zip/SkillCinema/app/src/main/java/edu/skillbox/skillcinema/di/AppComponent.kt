package edu.skillbox.skillcinema.di

//import dagger.Component
//import edu.skillbox.skillcinema.presentation.*
//
//@Component(
//    modules = [
//        PresentationModule::class,
//        DataModule::class
//    ]
//)
//interface AppComponent {
//
////    fun inject(welcome1Fragment: Welcome1Fragment)
//
//    fun welcomeViewModelFactory(): WelcomeViewModelFactory
//
//    fun mainViewModelFactory(): MainViewModelFactory
//
//    fun listPageFiltered1ViewModelFactory(): ListPageFiltered1ViewModelFactory
//
//    fun listPageFiltered2ViewModelFactory(): ListPageFiltered2ViewModelFactory
//
//}