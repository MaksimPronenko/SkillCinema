package edu.skillbox.skillcinema.models

class PagedFilmTopList (
    val pagesCount: Int,
    val films: List<FilmTop>
)