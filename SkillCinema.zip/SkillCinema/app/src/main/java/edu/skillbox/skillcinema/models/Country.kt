package edu.skillbox.skillcinema.models

data class Country(
    val country: String
)
