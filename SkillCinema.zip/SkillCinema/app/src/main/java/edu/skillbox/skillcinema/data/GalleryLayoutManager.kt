package edu.skillbox.skillcinema.data

//import android.content.Context
//import androidx.recyclerview.widget.GridLayoutManager
//
//class GalleryLayoutManager(context: Context, spanCount: Int): GridLayoutManager(context, spanCount) {
//
//    override fun setSpanSizeLookup(spanSizeLookup: SpanSizeLookup?) {
//        super.setSpanSizeLookup(spanSizeLookup)
//
//        spanCount
//    }
//}